#!/bin/bash

function mostrar_ayuda() {
    echo "Uso: $0 <origen> <destino>"
    echo
    echo "Ejemplo: $0 /var/log /backup_dir"
    echo
    echo "El script genera un archivo .tar.gz con la fecha actual."
    echo
    echo "Opciones:"
    echo "  -help        Muestra esta ayuda"
    exit 0
}

# Si se pide ayuda
if [[ "$1" == "-help" ]]; then
    mostrar_ayuda
fi

# Validación de parámetros
if [[ $# -ne 2 ]]; then
    echo "Error: Debes especificar un origen y un destino."
    echo "Ejemplo: $0 /var/log /backup_dir"
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"

# Validar existencia del origen
if [[ ! -d "$ORIGEN" ]]; then
    echo "Error: El directorio de origen '$ORIGEN' no existe."
    exit 2
fi

# Validar existencia del destino
if [[ ! -d "$DESTINO" ]]; then
    echo "Error: El directorio de destino '$DESTINO' no existe o no está montado."
    exit 3
fi

# Generar nombre de archivo
FECHA=$(date +%Y%m%d)
NOMBRE_ORIGEN=$(basename "$ORIGEN")
ARCHIVO="${DESTINO}/${NOMBRE_ORIGEN}_bkp_${FECHA}.tar.gz"

# Ejecutar backup
echo "Iniciando backup de '$ORIGEN' hacia '$ARCHIVO'..."
tar -czf "$ARCHIVO" "$ORIGEN"

# Validar resultado
if [[ $? -eq 0 ]]; then
    echo "Backup completado correctamente."
    echo "Archivo generado: $ARCHIVO"
else
    echo "Error durante el proceso de backup."
    exit 4
fi
